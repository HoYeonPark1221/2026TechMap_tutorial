SolarSystem 튜토리얼 · 시작하는 프로젝트
=======================================

튜토리얼이 가르치는 것은 두 가지입니다.

  1챕터  Spatial Layout으로 배치하기
         SpatialContainer, depthAlignment, HStackLayout,
         frame(depth:), rotation3DLayout
  2챕터  창과 몰입 공간 오가기
         ImmersiveSpaceState, openImmersiveSpace/dismissImmersiveSpace,
         immersionStyle(selection:in:), windowStyle(.plain)

나머지는 이 폴더에 들어 있습니다. 새로 만든 visionOS 프로젝트의 같은 이름
폴더에 그대로 끌어다 놓으세요.

놓기 전에 할 일
---------------
  1. visionOS ▸ App 템플릿으로 SolarSystem 프로젝트를 만듭니다.
     Initial Scene: Window / Immersive Space Renderer: RealityKit
     Immersive Space는 무엇을 골라도 됩니다. 이 폴더의 Info.plist가
     템플릿이 만든 SolarSystem/Info.plist를 덮어씁니다.
  2. Minimum Deployments를 visionOS 26.0으로 맞춥니다.
  3. SolarSystem-Assets.zip의 WorldAssets 패키지를 Add Local로 앱 타깃에
     연결하고, 이미지 세 개(Starfield, SolarSystem, SolarBackground)를
     Assets 카탈로그에, Resources/Sunlight.skybox를 프로젝트 Resources에
     넣습니다.
  4. 템플릿이 만든 ContentView.swift, ImmersiveView.swift, AppModel.swift,
     ToggleImmersiveSpaceButton.swift 네 개를 지웁니다. 앞의 둘은 쓰지
     않고, 뒤의 둘은 이 폴더와 튜토리얼이 대신 채웁니다.

!! 단 하나, Solar System/SolarSystemControls.swift만 빼 두세요.
   이 파일은 2챕터에서 만드는 ToggleImmersiveSpaceButton을 쓰기 때문에,
   지금 넣으면 1챕터 내내 빌드가 깨집니다. 2챕터 첫 섹션에서 넣습니다.

이 폴더에 들어 있는 파일
------------------------
  Info.plist                                   초기 몰입 스타일 설정 (템플릿 파일을 덮어쓸 것)
  SolarSystemApp.swift                         시스템 등록까지만 된 진입점 (2챕터에서 채움)
  Entities/EarthEntity+Configuration.swift     지구 설정값
  Entities/EarthEntity.swift                   지구 전용 엔티티 (Apple Hello World 샘플 기반)
  Entities/Entity+Sunlight.swift               이미지 기반 조명(IBL) 확장
  Entities/Entity+Trace.swift                  궤적 그리기 확장
  Entities/PlanetEntity+Configuration.swift    여덟 행성의 크기·궤도·속도 설정값
  Entities/PlanetEntity.swift                  공전·자전·자전축을 담은 엔티티 계층
  Entities/PlanetSelectionComponent.swift      핀치로 고른 행성을 되찾는 꼬리표
  Entities/SatelliteEntity+Configuration.swift 달·위성 설정값
  Entities/SatelliteEntity.swift               달과 인공위성 엔티티
  Model/AppModel.swift                         포커스 상태와 머리 추적 배치 (2챕터에서 보탬)
  Model/HeadTracker.swift                      ARKit으로 머리 위치를 읽는 도우미
  Model/Module.swift                           소개 카드에 쓰는 문구 모음
  Model/PlanetID.swift                         행성 여덟 개의 식별자·표시 이름·설명 문구
  RealityViews/Earth.swift                     지구 단독 미리보기용 뷰
  RealityViews/Planet.swift                    궤도를 도는 행성 하나와 핀치 제스처
  RealityViews/PlanetFocusLayout.swift         body만 비어 있음 (1챕터에서 채움)
  RealityViews/Starfield.swift                 별 배경 (거대한 구를 뒤집어 안쪽에 텍스처)
  RealityViews/Sun.swift                       태양 모델과 점광원
  Solar System/PlanetInfoPanel.swift           확대된 행성 옆에 뜨는 설명 창
  Solar System/SolarSystem.swift               몰입 공간의 내용 (2챕터에서 보탬)
  Solar System/SolarSystemControls.swift       창 안의 컨트롤 UI — 2챕터에서 넣을 것
  Solar System/SolarSystemModule.swift         소개 카드의 미리보기 이미지
  Systems/RotationSystem.swift                 회전 컴포넌트를 매 프레임 갱신하는 시스템
  Systems/TraceSystem.swift                    궤적을 매 프레임 갱신하는 시스템

튜토리얼에서 직접 만드는 파일
-----------------------------
  Solar System/SwitchWindows.swift               1챕터 (2챕터에서 배선 보탬)
  Solar System/SolarCard.swift                   1챕터
  RealityViews/PlanetFocusLayout.swift 의 body   1챕터
  Model/AppModel.swift 의 몰입 공간 상태         2챕터
  Solar System/ToggleImmersiveSpaceButton.swift  2챕터
  Solar System/SolarSystem.swift 의 생명주기     2챕터
  SolarSystemApp.swift 의 Scene 두 개            2챕터

이 폴더의 파일과 튜토리얼에서 쓴 코드를 합치면 완성된 앱과 정확히 같아집니다.

별 배경 이미지와 행성 모델 패키지는 SolarSystem-Assets.zip으로 따로
제공됩니다.
