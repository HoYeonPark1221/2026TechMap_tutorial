SolarSystem 튜토리얼 · 시작 프로젝트
===================================

폴더와 파일이 모두 갖춰져 있습니다. 모델 패키지만 넣으면 바로 빌드됩니다.

시작하기
--------
  1. SolarSystem-Assets.zip의 WorldAssets 폴더를 이 프로젝트의 Packages 안으로
     복사합니다. Packages/WorldAssets/Package.swift가 되어야 합니다.
     (약 300MB라 프로젝트 zip에는 넣지 않았습니다. 프로젝트는 이 경로를 이미
     참조하므로 Add Local로 다시 연결할 필요는 없습니다.)
  2. SolarSystem.xcodeproj를 엽니다.
  3. Apple Vision Pro 시뮬레이터로 Command + R. 창에 "Solar System" 글자만
     뜨면 정상입니다.

이 프로젝트는 동기화 폴더(Xcode 16+)를 씁니다. 폴더에 .swift 파일을 넣으면
Xcode가 알아서 타깃에 포함하므로, 파일을 따로 추가할 필요가 없습니다.

폴더
----
  Entities/    RealityKit 엔티티와 설정값
  Systems/     매 프레임 도는 시스템 (회전, 궤적)
  RealityViews/ 엔티티를 화면에 올리는 뷰
  Scenes/      창과 몰입 공간
  Model/       앱 상태와 문구
  Resources/   이미지 에셋과 조명용 스카이박스

이름 규칙: 프로젝트 이름(SolarSystem)과 겹치는 폴더·파일을 두지 않았습니다.
몰입 공간 쪽 뷰는 ImmersiveSolarSystem, 그 폴더는 Scenes입니다.

튜토리얼에서 직접 쓰는 곳
-------------------------
  2챕터  Scenes/SwitchWindows.swift          새로 만듦
         Scenes/SolarCard.swift              새로 만듦
         RealityViews/PlanetFocusLayout.swift  body
  3챕터  Model/AppModel.swift                몰입 공간 상태
         Scenes/ToggleImmersiveSpaceButton.swift  속
         Scenes/ImmersiveSolarSystem.swift   onAppear / task / onDisappear
         SolarSystemApp.swift                Scene 두 개

비어 있는 자리마다 몇 챕터에서 채우는지 주석으로 적어 두었습니다.
여기를 모두 채우면 완성된 앱과 같아집니다.
