//
//  SolarSystemApp.swift
//  SolarSystem
//
//  Created by Saerom on 8/12/26.
//

import RealityKit
import SwiftUI
import WorldAssets

@main
struct SolarSystemApp: App {

    init() {
        // Custom RealityKit systems must be registered once before they'll
        // run -- without this, RotationComponent/TraceComponent entities
        // never actually rotate or draw a trace, and Earth's day/night
        // shading never updates.
        RotationSystem.registerSystem()
        TraceSystem.registerSystem()
        SunPositionSystem.registerSystem()
    }

    // 창과 몰입 공간을 Scene으로 등록하는 일은 튜토리얼 2챕터
    // "@main에서 두 Scene 잇기"에서 합니다.
    var body: some SwiftUI.Scene {
        WindowGroup {
            Text("Solar System")
        }
     }
}
    
