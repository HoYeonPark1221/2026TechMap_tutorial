//
//  ImmersiveSolarSystem.swift
//  SolarSystem
//
//  Created by Saerom on 8/13/26.
//
/// 태양 + 행성들 ZStack으로 쌓는곳


/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The model content for the solar system module.
*/

import SwiftUI
import RealityKit

/// The model content for the solar system module.
struct ImmersiveSolarSystem: View {
    @Environment(AppModel.self) private var model

    /// Converts the head-tracked placement, which `AppModel` computes in
    /// meters, into the points SwiftUI positions views in.
    @PhysicalMetric(from: .meters) private var pointsPerMeter: CGFloat = 1

    var body: some View {
        ZStack {
            Starfield()

            Sun(
                scale: model.solarSunScale,
                position: model.solarSunPosition,
                isHidden: model.focusedPlanetID != nil
            )

            ForEach(model.solarPlanets, id: \.id) { configuration in
                Planet(configuration: configuration)
            }

            // Turned to face the viewer and pushed out along their gaze.
            // The layout centers the planet and panel on each other, so
            // placing its center is all this has to do.
            if let focused = model.focusedConfiguration {
                PlanetFocusLayout(configuration: focused)
                    .transition(.opacity)
                    .rotation3DEffect(.radians(Double(model.focusPlacement.yaw)),
                                      axis: (x: 0, y: 1, z: 0))
                    .offset(x: CGFloat(model.focusPlacement.position.x) * pointsPerMeter,
                            y: CGFloat(-model.focusPlacement.position.y) * pointsPerMeter)
                    .offset(z: CGFloat(model.focusPlacement.position.z) * pointsPerMeter)
            }
        }
        // 3챕터에서 이 자리에 onAppear / task / onDisappear를 씁니다.
    }
}
