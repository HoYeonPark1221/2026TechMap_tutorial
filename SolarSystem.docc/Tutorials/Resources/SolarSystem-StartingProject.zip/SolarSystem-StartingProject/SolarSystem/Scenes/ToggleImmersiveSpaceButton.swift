//
//  ToggleImmersiveSpaceButton.swift
//  SolarSystem
//

import SwiftUI

/// 몰입 공간을 여닫는 버튼. 3챕터에서 속을 채웁니다.
struct ToggleImmersiveSpaceButton: View {
    var body: some View {
        Button("Going to the Solar System") { }
            .fontWeight(.semibold)
    }
}
