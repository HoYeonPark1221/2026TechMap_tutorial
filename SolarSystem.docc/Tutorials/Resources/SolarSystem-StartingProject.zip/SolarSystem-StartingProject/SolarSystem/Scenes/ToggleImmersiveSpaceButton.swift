import SwiftUI

// 3챕터에서 속을 채웁니다.
struct ToggleImmersiveSpaceButton: View {
    var body: some View {
        Button("Going to the Solar System") { }
            .fontWeight(.semibold)
    }
}
