/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The module detail content that's specific to the solar system module.
*/

import SwiftUI

struct SolarSystemModule: View {
    var body: some View {
        Image("SolarSystem")
            .resizable()
            .scaledToFit()
    }
}

#Preview {
    SolarSystemModule()
        .padding()
}
