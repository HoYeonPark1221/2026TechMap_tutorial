import RealityKit
import SwiftUI
import WorldAssets

@main
struct SolarSystemApp: App {

    init() {
        RotationSystem.registerSystem()
        TraceSystem.registerSystem()
        SunPositionSystem.registerSystem()
    }

    // 3챕터에서 이 자리에 창과 몰입 공간 Scene을 씁니다.
    var body: some SwiftUI.Scene {
        WindowGroup {
            Text("Solar System")
        }
     }
}
