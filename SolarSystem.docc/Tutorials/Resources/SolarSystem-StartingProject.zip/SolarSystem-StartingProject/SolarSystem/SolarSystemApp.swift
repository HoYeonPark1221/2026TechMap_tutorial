//
//  SolarSystemApp.swift
//  SolarSystem
//
//  Created by Saerom on 8/12/26.
//

import RealityKit
import SwiftUI
import WorldAssets

@main
struct SolarSystemApp: App {

    init() {
        // Custom RealityKit systems must be registered once before they'll
        // run -- without this, RotationComponent/TraceComponent entities
        // never actually rotate or draw a trace, and Earth's day/night
        // shading never updates.
        RotationSystem.registerSystem()
        TraceSystem.registerSystem()
        SunPositionSystem.registerSystem()
    }

    // 3챕터에서 이 자리에 창과 몰입 공간 Scene을 씁니다.
    var body: some SwiftUI.Scene {
        WindowGroup {
            Text("Solar System")
        }
     }
}
    
