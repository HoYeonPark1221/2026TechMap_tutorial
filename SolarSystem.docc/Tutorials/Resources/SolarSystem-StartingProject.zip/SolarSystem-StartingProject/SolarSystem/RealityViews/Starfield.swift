/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
A large sphere that has an image of the night sky on its inner surface.
*/

import SwiftUI
import RealityKit

struct Starfield: View {
    var body: some View {
        RealityView { content in
            guard let resource = try? await TextureResource(named: "Starfield") else {
                fatalError("Unable to load starfield texture.")
            }
            var material = UnlitMaterial()
            material.color = .init(texture: .init(resource))

            let entity = Entity()
            entity.components.set(ModelComponent(
                mesh: .generateSphere(radius: 1000),
                materials: [material]
            ))

            entity.scale *= .init(x: -1, y: 1, z: 1)

            content.add(entity)
        }
    }
}
