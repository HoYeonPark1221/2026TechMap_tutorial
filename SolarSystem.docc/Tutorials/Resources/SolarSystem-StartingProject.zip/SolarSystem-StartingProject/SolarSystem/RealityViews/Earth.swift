/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The model of the Earth.
*/

import SwiftUI
import RealityKit
import WorldAssets

struct Earth: View {
    var earthConfiguration: EarthEntity.Configuration = .init()
    var satelliteConfiguration: [SatelliteEntity.Configuration] = []
    var moonConfiguration: SatelliteEntity.Configuration? = nil
    var animateUpdates: Bool = false
    var axCustomActionHandler: ((_: AccessibilityEvents.CustomAction) -> Void)? = nil

    @State private var earthEntity: EarthEntity?

    var body: some View {
        RealityView { content in
            let earthEntity = await EarthEntity(
                configuration: earthConfiguration,
                satelliteConfiguration: satelliteConfiguration,
                moonConfiguration: moonConfiguration)
            content.add(earthEntity)

            if let axCustomActionHandler {
                _ = content.subscribe(
                    to: AccessibilityEvents.CustomAction.self,
                    on: nil,
                    componentType: nil,
                    axCustomActionHandler)
            }

            self.earthEntity = earthEntity

        } update: { content in
            earthEntity?.update(
                configuration: earthConfiguration,
                satelliteConfiguration: satelliteConfiguration,
                moonConfiguration: moonConfiguration,
                animateUpdates: animateUpdates)
        }
    }
}

#Preview {
    Earth(
        earthConfiguration: EarthEntity.Configuration.orbitEarthDefault,
        satelliteConfiguration: [
            SatelliteEntity.Configuration(
                name: "Satellite",
                displayName: "Satellite",
                isVisible: true,
                inclination: .degrees(30),
                speedRatio: 10,
                scale: 1,
                altitude: 0.4,
                traceWidth: 400,
                isTraceVisible: true)
        ]
    )
}
