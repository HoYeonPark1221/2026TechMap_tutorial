/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
The model of the sun.
*/

import SwiftUI
import RealityKit
import WorldAssets

struct Sun: View {
    var scale: Float = 1
    var position: SIMD3<Float> = .zero
    var isHidden: Bool = false

    @State private var sun: Entity?
    @State private var light: Entity?

    var body: some View {
        RealityView { content in
            guard let sun = await WorldAssets.entity(named: "Sun") else {
                return
            }
            content.add(sun)
            self.sun = sun

            let light = Entity()
            light.components.set(PointLightComponent(color: .white, intensity: 200_000, attenuationRadius: 60))
            content.add(light)
            self.light = light

            configure()

        } update: { content in
            configure()
        }
    }

    private func configure() {
        sun?.scale = SIMD3(repeating: scale)
        sun?.position = position
        sun?.isEnabled = !isHidden
        light?.position = position
    }
}

#Preview {
    Sun(scale: 0.1)
}
