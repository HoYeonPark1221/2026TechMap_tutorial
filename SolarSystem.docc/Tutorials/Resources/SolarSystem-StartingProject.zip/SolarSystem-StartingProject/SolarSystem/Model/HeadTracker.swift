import ARKit
import QuartzCore

@MainActor
final class HeadTracker {
    private var session = ARKitSession()
    private var worldTracking = WorldTrackingProvider()

    func start() async {
        session = ARKitSession()
        worldTracking = WorldTrackingProvider()
        guard WorldTrackingProvider.isSupported else { return }
        do {
            try await session.run([worldTracking])
        } catch {
            print("Failed to start world tracking: \(error)")
        }
    }

    func stop() {
        session.stop()
    }

    func headTransform() -> simd_float4x4? {
        guard worldTracking.state == .running,
              let anchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime())
        else { return nil }
        return anchor.originFromAnchorTransform
    }
}
