/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
An entity that represents the Earth and all its moving parts.
*/

import RealityKit
import SwiftUI
import WorldAssets

class EarthEntity: Entity {

    private var earth: Entity = Entity()

    private let equatorialPlane = Entity()

    private let rotator = Entity()

    private var pole: Entity = Entity()

    private var moon: SatelliteEntity = SatelliteEntity()

    private let satellites = Entity()

    private var currentSunIntensity: Float? = nil

    @MainActor required init() {
        super.init()
    }

    init(
        configuration: Configuration,
        satelliteConfiguration: [SatelliteEntity.Configuration],
        moonConfiguration: SatelliteEntity.Configuration?
    ) async {
        super.init()

        guard let earth = await WorldAssets.entity(named: configuration.isCloudy ? "Earth" : "Globe"),
              let pole = await WorldAssets.entity(named: "Pole") else { return }
        self.earth = earth
        self.pole = pole

        for configuration in satelliteConfiguration {
            await satellites.addChild(SatelliteEntity(configuration))
        }

        self.addChild(equatorialPlane)
        equatorialPlane.addChild(rotator)
        rotator.addChild(earth)

        earth.addChild(pole)

        moon = await SatelliteEntity(.orbitMoonDefault)
        self.addChild(moon)

        equatorialPlane.addChild(satellites)

        update(
            configuration: configuration,
            satelliteConfiguration: satelliteConfiguration,
            moonConfiguration: moonConfiguration,
            animateUpdates: false)
    }

    func update(
        configuration: Configuration,
        satelliteConfiguration: [SatelliteEntity.Configuration],
        moonConfiguration: SatelliteEntity.Configuration?,
        animateUpdates: Bool
    ) {
        earth.sunPositionComponent = SunPositionComponent(Float(configuration.sunAngle.radians))

        rotator.orientation = configuration.rotation

        if var rotation: RotationComponent = earth.components[RotationComponent.self] {
            rotation.speed = configuration.currentSpeed
            earth.components[RotationComponent.self] = rotation
        } else {
            earth.components.set(RotationComponent(speed: configuration.currentSpeed))
        }

        moon.update(
            configuration: moonConfiguration ?? .disabledMoon,
            speed: configuration.currentSpeed,
            traceAnchor: self)

        for satellite in satellites.children {
            guard let satelliteConfiguration = satelliteConfiguration.first(where: { $0.name == satellite.name }) else { continue }
            (satellite as? SatelliteEntity)?.update(
                configuration: satelliteConfiguration,
                speed: configuration.currentSpeed,
                traceAnchor: earth)
        }

        pole.isEnabled = configuration.showPoles
        pole.scale = [
            configuration.poleThickness,
            configuration.poleLength,
            configuration.poleThickness]

        if configuration.currentSunIntensity != currentSunIntensity {
            setSunlight(intensity: configuration.currentSunIntensity)
            currentSunIntensity = configuration.currentSunIntensity
        }

        var planeTransform = equatorialPlane.transform
        planeTransform.rotation = tilt(date: configuration.date)
        if animateUpdates {
            equatorialPlane.move(to: planeTransform, relativeTo: self, duration: 0.25)
        } else {
            equatorialPlane.move(to: planeTransform, relativeTo: self)
        }

        move(
            to: Transform(
                scale: SIMD3(repeating: configuration.scale),
                rotation: orientation,
                translation: configuration.position),
            relativeTo: parent)

        components.set(makeAxComponent(
            configuration: configuration,
            satelliteConfiguration: satelliteConfiguration,
            moonConfiguration: moonConfiguration))
    }

    private func makeAxComponent(
        configuration: Configuration,
        satelliteConfiguration: [SatelliteEntity.Configuration],
        moonConfiguration: SatelliteEntity.Configuration?
    ) -> AccessibilityComponent {
        var axComponent = AccessibilityComponent()
        axComponent.isAccessibilityElement = true

        axComponent.label = "Earth model"

        var axValueComponents = [String]()
        axValueComponents.append(configuration.currentSpeed != 0
                                 ? String(localized: "Rotating.", comment: "Describes an attribute of the Earth model.")
                                 : String(localized: "Not rotating.", comment: "Describes an attribute of the Earth model."))
        axValueComponents.append(configuration.showSun
                                 ? String(localized: "The sun is shining.", comment: "Describes an attribute of the Earth model.")
                                 : String(localized: "The sun is not shining.", comment: "Describes an attribute of the Earth model."))
        if configuration.axDescribeTilt {
            if let dateString = configuration.date?.formatted(.dateTime.day().month(.wide)) {
                axValueComponents.append(String(localized: "The Earth is tilted for the date \(dateString).",
                                                comment: "Describes an attribute of the Earth model."))
            } else {
                axValueComponents.append(String(localized: "The Earth is not tilted.", comment: "Describes an attribute of the Earth model."))
            }
        }
        if configuration.showPoles {
            axValueComponents.append(String(localized: "The poles indicated.", comment: "Describes an attribute of the Earth model."))
        }
        for item in satelliteConfiguration.map({ $0.name }) {
            axValueComponents.append(String(localized: "A \(item) orbits close to the earth.",
                                            comment: "Describes an attribute of the Earth model. The first parameter is any satellite."))
        }
        if moonConfiguration != nil {
            axValueComponents.append(String(localized: "The moon orbits at some distance from the earth.",
                                            comment: "Describes an attribute of the Earth model."))
        }
        let axValue = axValueComponents.joined(separator: String(localized: " ",
                                                                 comment: """
                                                                          Separator between accessibility description components.
                                                                          This separator is a space to separate the sentences.
                                                                          """))
        axComponent.value = LocalizedStringResource(stringLiteral: axValue)

        if !configuration.axActions.isEmpty {
            axComponent.customActions.append(contentsOf: configuration.axActions)
        }

        return axComponent
    }

    private func tilt(date: Date?) -> simd_quatf {
        let tiltAngle: Angle = .degrees(date == nil ? 0 : 23.5)

        let calendar = Calendar.autoupdatingCurrent
        let day = calendar.ordinality(of: .day, in: .year, for: date ?? Date()) ?? 1

        let axisAngle: Float = (Float(day) / 365.0) * 2.0 * .pi

        let tiltAxis: SIMD3<Float> = [
            sin(axisAngle),
            0,
            -cos(axisAngle)
        ]

        return simd_quatf(angle: Float(tiltAngle.radians), axis: tiltAxis)
    }
}
