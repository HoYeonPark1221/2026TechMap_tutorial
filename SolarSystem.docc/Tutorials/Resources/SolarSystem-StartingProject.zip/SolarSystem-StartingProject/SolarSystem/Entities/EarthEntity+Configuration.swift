/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
Configuration information for Earth entities.
*/

import SwiftUI

extension EarthEntity {
    struct Configuration {
        var isCloudy: Bool = false

        var scale: Float = 0.6
        var rotation: simd_quatf = .init(angle: 0, axis: [0, 1, 0])
        var speed: Float = 0
        var isPaused: Bool = false
        var position: SIMD3<Float> = .zero
        var date: Date? = nil

        var showPoles: Bool = false
        var poleLength: Float = 0.875
        var poleThickness: Float = 0.75

        var showSun: Bool = true
        var sunIntensity: Float = 14
        var sunAngle: Angle = .degrees(280)

        var axActions: [LocalizedStringResource] = []
        var axDescribeTilt: Bool = false

        var currentSpeed: Float {
            isPaused ? 0 : speed
        }

        var currentSunIntensity: Float? {
            showSun ? sunIntensity : nil
        }

        static var globeEarthDefault: Configuration = .init(
            axActions: AccessibilityActions.rotate,
            axDescribeTilt: true
        )

        static var orbitEarthDefault: Configuration = .init(
            scale: 0.4,
            speed: 0.1,
            date: Date(),
            axActions: AccessibilityActions.zoom)

        static var solarEarthDefault: Configuration = .init(
            isCloudy: true,
            scale: 0.7,
            speed: 0.045,
            position: .zero,
            date: Date())
    }

    enum AccessibilityActions {
        case zoomIn, zoomOut, rotateCW, rotateCCW

        var name: LocalizedStringResource {
            switch self {
            case .zoomIn: "Zoom in"
            case .zoomOut: "Zoom out"
            case .rotateCW: "Rotate clockwise"
            case .rotateCCW: "Rotate counterclockwise"
            }
        }

        static var zoom: [LocalizedStringResource] {
            [zoomIn.name, zoomOut.name]
        }

        static var rotate: [LocalizedStringResource] {
            [rotateCW.name, rotateCCW.name]
        }
    }
}
