import SwiftUI

extension PlanetEntity {
    enum ModelKind {
        case earth(configuration: EarthEntity.Configuration, satellites: [SatelliteEntity.Configuration], moon: SatelliteEntity.Configuration?)
        case placeholder(color: Color)
    }

    struct Configuration {
        var id: PlanetID
        var modelKind: ModelKind

        var orbitRadius: Float
        var initialOrbitAngle: Angle = .zero

        var visualRadius: Float = 0.2
        var ringRadius: Float = 0.35

        var axialTilt: Angle = .zero
        var rotationSpeed: Float = 0
        var revolutionSpeed: Float = 0

        var sceneCenter: SIMD3<Float> = .zero
        var presentationTilt: simd_quatf = .init(angle: 0, axis: [0, 1, 0])

        var isPaused: Bool = false
        var isHidden: Bool = false

        var currentRevolutionSpeed: Float { isPaused ? 0 : revolutionSpeed }
        var currentRotationSpeed: Float { isPaused ? 0 : rotationSpeed }
    }
}

extension PlanetEntity.Configuration {
    private static let earthRotationSpeed: Float = 0.045
    private static let earthRevolutionSpeed: Float = 0.05

    static var mercury: Self {
        .init(
            id: .mercury,
            modelKind: .placeholder(color: Color(red: 0.61, green: 0.61, blue: 0.58)),
            orbitRadius: 1.2,
            initialOrbitAngle: .degrees(20),
            visualRadius: 0.15,
            ringRadius: 0.19,
            axialTilt: .degrees(0.03),
            rotationSpeed: earthRotationSpeed * 0.017,
            revolutionSpeed: earthRevolutionSpeed * 1.65)
    }

    static var venus: Self {
        .init(
            id: .venus,
            modelKind: .placeholder(color: Color(red: 0.91, green: 0.80, blue: 0.64)),
            orbitRadius: 1.75,
            initialOrbitAngle: .degrees(95),
            visualRadius: 0.22,
            ringRadius: 0.27,
            axialTilt: .degrees(177.4),
            rotationSpeed: -earthRotationSpeed * 0.0041,
            revolutionSpeed: earthRevolutionSpeed * 1.19)
    }

    static func makeEarth(
        configuration: EarthEntity.Configuration,
        satellites: [SatelliteEntity.Configuration],
        moon: SatelliteEntity.Configuration?
    ) -> Self {
        .init(
            id: .earth,
            modelKind: .earth(configuration: configuration, satellites: satellites, moon: moon),
            orbitRadius: 2.65,
            initialOrbitAngle: .degrees(160),
            ringRadius: 0.44,
            axialTilt: .zero,
            rotationSpeed: 0,
            revolutionSpeed: earthRevolutionSpeed,
            isPaused: configuration.isPaused)
    }

    static var mars: Self {
        .init(
            id: .mars,
            modelKind: .placeholder(color: Color(red: 0.76, green: 0.35, blue: 0.24)),
            orbitRadius: 3.5,
            initialOrbitAngle: .degrees(210),
            visualRadius: 0.17,
            ringRadius: 0.21,
            axialTilt: .degrees(25.2),
            rotationSpeed: earthRotationSpeed * 0.972,
            revolutionSpeed: earthRevolutionSpeed * 0.80)
    }

    static var jupiter: Self {
        .init(
            id: .jupiter,
            modelKind: .placeholder(color: Color(red: 0.79, green: 0.64, blue: 0.42)),
            orbitRadius: 4.25,
            initialOrbitAngle: .degrees(30),
            visualRadius: 0.42,
            ringRadius: 0.52,
            axialTilt: .degrees(3.1),
            rotationSpeed: earthRotationSpeed * 2.41,
            revolutionSpeed: earthRevolutionSpeed * 0.42)
    }

    static var saturn: Self {
        .init(
            id: .saturn,
            modelKind: .placeholder(color: Color(red: 0.86, green: 0.78, blue: 0.57)),
            orbitRadius: 5.75,
            initialOrbitAngle: .degrees(275),
            visualRadius: 0.38,
            ringRadius: 0.47,
            axialTilt: .degrees(26.7),
            rotationSpeed: earthRotationSpeed * 2.24,
            revolutionSpeed: earthRevolutionSpeed * 0.31)
    }

    static var uranus: Self {
        .init(
            id: .uranus,
            modelKind: .placeholder(color: Color(red: 0.62, green: 0.84, blue: 0.87)),
            orbitRadius: 7.1,
            initialOrbitAngle: .degrees(120),
            visualRadius: 0.27,
            ringRadius: 0.34,
            axialTilt: .degrees(97.8),
            rotationSpeed: -earthRotationSpeed * 1.39,
            revolutionSpeed: earthRevolutionSpeed * 0.21)
    }

    static var neptune: Self {
        .init(
            id: .neptune,
            modelKind: .placeholder(color: Color(red: 0.24, green: 0.37, blue: 0.80)),
            orbitRadius: 7.8,
            initialOrbitAngle: .degrees(340),
            visualRadius: 0.26,
            ringRadius: 0.33,
            axialTilt: .degrees(28.3),
            rotationSpeed: earthRotationSpeed * 1.49,
            revolutionSpeed: earthRevolutionSpeed * 0.17)
    }
}
