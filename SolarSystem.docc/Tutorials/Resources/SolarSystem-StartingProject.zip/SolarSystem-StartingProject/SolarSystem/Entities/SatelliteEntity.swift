/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
A satellite entity.
*/

import RealityKit
import SwiftUI
import WorldAssets

class SatelliteEntity: Entity {

    private var satellite = Entity()
    private let box = Entity()
    private let orbit = Entity()

    @MainActor required init() {
        super.init()
    }

    init(_ configuration: Configuration) async {
        super.init()

        guard let satellite = await WorldAssets.entity(named: configuration.name) else {
            return
        }
        self.satellite = satellite

        name = configuration.name
        isEnabled = configuration.isVisible

        orbit.components.set(RotationComponent(speed: 0))
        orbit.orientation = .init(angle: Float(configuration.initialRotation.radians), axis: [0, 1, 0])
        self.addChild(orbit)

        orbit.addChild(box)

        box.addChild(satellite)
    }

    func update(
        configuration: Configuration,
        speed: Float,
        traceAnchor: Entity
    ) {
        var resetTrace = !configuration.isTraceVisible

        let newOrientation = simd_quatf(angle: Float(configuration.inclination.radians), axis: [0, 0, 1])
        if newOrientation != self.orientation {
            resetTrace = true
        }
        orientation = newOrientation
        isEnabled = configuration.isVisible

        if var rotation: RotationComponent = orbit.components[RotationComponent.self] {
            rotation.speed = configuration.speedRatio * speed
            orbit.components[RotationComponent.self] = rotation
        }

        box.scale = SIMD3(repeating: configuration.scale)
        box.position = [0, 0, configuration.altitude]

        satellite.updateTrace(
            anchor: traceAnchor,
            width: configuration.traceWidth,
            isVisible: configuration.isTraceVisible,
            isPaused: (configuration.speedRatio * speed) == 0)
        if resetTrace {
            satellite.resetTrace()
        }
    }
}
