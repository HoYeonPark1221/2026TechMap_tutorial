import RealityKit
import SwiftUI

class PlanetEntity: Entity {

    private let orbitPivot = Entity()
    private let radiusOffset = Entity()
    private let equatorialPlane = Entity()
    private let rotator = Entity()
    private let orbitPath = Entity()
    private let selectionTarget = Entity()

    private var model: Entity = Entity()

    private var earthEntity: EarthEntity?

    let planetID: PlanetID
    private var configuration: Configuration
    private var isFocused = false

    @MainActor required init() {
        planetID = .mercury
        configuration = .mercury
        super.init()
    }

    init(configuration: Configuration) async {
        self.planetID = configuration.id
        self.configuration = configuration
        super.init()

        addChild(orbitPivot)
        addChild(orbitPath)
        orbitPivot.addChild(radiusOffset)
        radiusOffset.addChild(equatorialPlane)
        equatorialPlane.addChild(rotator)

        position = configuration.sceneCenter
        orientation = configuration.presentationTilt

        Self.configureOrbitPath(orbitPath, orbitRadius: configuration.orbitRadius)

        orbitPivot.orientation = .init(angle: Float(configuration.initialOrbitAngle.radians), axis: [0, 1, 0])

        equatorialPlane.orientation = Self.tiltOrientation(configuration.axialTilt)

        switch configuration.modelKind {
        case let .earth(earthConfiguration, satellites, moon):
            let earth = await EarthEntity(
                configuration: earthConfiguration,
                satelliteConfiguration: satellites,
                moonConfiguration: moon)
            earthEntity = earth
            model = earth

        case let .placeholder(color):
            model = await Self.loadPlaceholderModel(
                assetName: configuration.id.assetName,
                radius: configuration.visualRadius,
                color: color)
        }
        rotator.addChild(model)

        rotator.addChild(selectionTarget)
        Self.configureSelectionTarget(selectionTarget, planetID: configuration.id, radius: configuration.ringRadius)

        update(configuration: configuration, animateUpdates: false)
    }

    func update(configuration: Configuration, animateUpdates: Bool) {
        self.configuration = configuration

        isEnabled = !configuration.isHidden

        radiusOffset.position = [0, 0, configuration.orbitRadius]

        setRotationSpeed(isFocused ? 0 : configuration.currentRevolutionSpeed, on: orbitPivot)
        setRotationSpeed(configuration.currentRotationSpeed, on: rotator)

        switch configuration.modelKind {
        case let .earth(earthConfiguration, satellites, moon):
            earthEntity?.update(
                configuration: earthConfiguration,
                satelliteConfiguration: satellites,
                moonConfiguration: moon,
                animateUpdates: animateUpdates)

        case .placeholder:
            model.scale = SIMD3(repeating: configuration.visualRadius)
        }
    }

    private func setRotationSpeed(_ speed: Float, on entity: Entity) {
        if var rotation: RotationComponent = entity.components[RotationComponent.self] {
            rotation.speed = speed
            entity.components[RotationComponent.self] = rotation
        } else {
            entity.components.set(RotationComponent(speed: speed))
        }
    }

    static let focusDisplayRadius: Float = 0.35
    static let focusPanelScale: Float = 1.4
    static let focusPanelHalfWidth: Float = 0.28 * focusPanelScale
    static let focusPanelOffset: Float = focusDisplayRadius + 0.1 + focusPanelHalfWidth

    private var focusScale: Float {
        Self.focusDisplayRadius / max(configuration.ringRadius, 0.05)
    }

    func setFocused(_ focused: Bool, stage: Entity, animated: Bool = true) {
        guard focused != isFocused else { return }
        isFocused = focused

        let newParent = focused ? stage : radiusOffset
        newParent.addChild(equatorialPlane, preservingWorldTransform: true)

        let scale: Float = focused ? focusScale : 1
        let target = Transform(
            scale: SIMD3(repeating: scale),
            rotation: Self.tiltOrientation(configuration.axialTilt),
            translation: .zero)
        if animated {
            equatorialPlane.move(to: target, relativeTo: newParent, duration: 0.6)
        } else {
            equatorialPlane.move(to: target, relativeTo: newParent)
        }

        setRotationSpeed(focused ? 0 : configuration.currentRevolutionSpeed, on: orbitPivot)
    }

    private static func configureSelectionTarget(_ target: Entity, planetID: PlanetID, radius: Float) {
        target.name = "\(planetID.displayName)-selectionTarget"
        target.components.set(PlanetSelectionComponent(planetID: planetID))
        target.components.set(InputTargetComponent())
        target.components.set(HoverEffectComponent())
        target.components.set(CollisionComponent(shapes: [.generateSphere(radius: max(radius, 0.05))]))
    }
}
