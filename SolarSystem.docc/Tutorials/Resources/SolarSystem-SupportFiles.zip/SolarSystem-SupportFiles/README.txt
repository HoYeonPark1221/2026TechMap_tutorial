SolarSystem 튜토리얼 · 함께 쓰는 파일
=====================================

한 줄씩 따라 쓰지 않고 그대로 받아 쓰는 코드입니다. 설정값·문구만 들어 있거나,
이 튜토리얼의 세 가지 주제(Component/System, 공간 입력, Spatial Layout)와 관계없는
코드라서 직접 쓰지 않습니다.

각 챕터의 첫 단계에서 "ChapterN 폴더의 내용을 옮기세요"라고 안내합니다.
그때 해당 폴더 안의 하위 폴더를 프로젝트의 같은 이름 폴더로 끌어다 놓으세요.
(Xcode에서 끌어다 놓을 때 Add to targets의 SolarSystem을 체크합니다.)
한꺼번에 미리 옮기면, 아직 만들지 않은 타입을 찾지 못해 빌드가 실패합니다.


ChapterN 폴더 · 챕터를 시작할 때 옮기는 파일
--------------------------------------------
Chapter2  창과 몰입 공간 열기
  RealityViews/Starfield.swift                 별 배경 (거대한 구를 뒤집어 안쪽에 텍스처)
  RealityViews/Sun.swift                       태양 모델과 점광원

Chapter3  Component와 System으로 행성 움직이기
  Entities/PlanetEntity+Configuration.swift    여덟 행성의 크기·궤도·속도 설정값
  Entities/PlanetEntity+Helpers.swift          모델 로딩, 궤도선 메시 생성
  Entities/EarthEntity.swift                   지구 전용 엔티티 (Apple Hello World 샘플 기반)
  Entities/EarthEntity+Configuration.swift     지구 설정값
  Entities/SatelliteEntity.swift               달과 인공위성 엔티티
  Entities/SatelliteEntity+Configuration.swift 달·위성 설정값
  Entities/Entity+Sunlight.swift               이미지 기반 조명(IBL) 확장
  Entities/Entity+Trace.swift                  궤적 그리기 확장
  Model/PlanetID.swift                         행성 여덟 개의 식별자·표시 이름·설명 문구
  Systems/TraceSystem.swift                    궤적을 매 프레임 갱신하는 시스템
  RealityViews/Earth.swift                     지구 단독 미리보기용 뷰

Chapter4  보고, 집고, 불러오기
  Model/HeadTracker.swift                      ARKit으로 머리 위치를 읽는 도우미
  Solar System/PlanetInfoPanel.swift           확대된 행성 옆에 뜨는 설명 패널

Chapter5  Spatial Layout으로 창 만들기
  Model/Module.swift                           소개 카드에 쓰는 문구 모음
  Solar System/SolarSystemControls.swift       몰입 공간이 열려 있을 때의 창 UI
  Solar System/SolarSystemModule.swift         카드 오른쪽 미리보기 이미지


튜토리얼에서 직접 작성하는 파일
-------------------------------
  SolarSystemApp.swift                           1, 2, 3, 5챕터
  Model/AppModel.swift                           2~5챕터
  Solar System/ToggleImmersiveSpaceButton.swift  2챕터
  Solar System/SolarSystem.swift                 2~5챕터
  Systems/RotationSystem.swift                   3챕터  ← Component / System
  Entities/PlanetEntity.swift                    3~4챕터
  RealityViews/Planet.swift                      3~4챕터
  Entities/PlanetSelectionComponent.swift        4챕터  ← 공간 입력
  RealityViews/FocusStage.swift                  4챕터
  Solar System/SolarCard.swift                   5챕터  ← Spatial Layout
  Solar System/SwitchWindows.swift               5챕터


Checkpoints 폴더 · 막혔을 때 비교하기
-------------------------------------
각 챕터를 마친 시점의 소스 파일 전체입니다. 빌드 오류가 나거나 결과가 다르면
같은 챕터의 폴더와 내 프로젝트를 비교해 보세요. Checkpoints/Chapter5가 완성된
앱의 전체 소스입니다.


별 배경 이미지와 행성 모델 패키지는 1챕터의 SolarSystem-Assets.zip으로 따로 제공됩니다.
